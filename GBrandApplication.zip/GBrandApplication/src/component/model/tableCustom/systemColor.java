package component.model.tableCustom;

import java.awt.Color;

public class systemColor {

    public final static Color MAIN_COLOR_1 = Color.decode("#8f94fb");
    public final static Color MAIN_COLOR_2 = Color.decode("#4e54c8");
}
