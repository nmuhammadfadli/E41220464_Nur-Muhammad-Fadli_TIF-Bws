package component.model;

import java.awt.Color;

public class systemColor {

    public final static Color MAIN_COLOR_1 = Color.decode("#FFFFFF");
    public final static Color MAIN_COLOR_2 = Color.decode("#0033FF");
}
